Koyote is a Freeware Neo Geo Pocket emulator, use it at your own risk.

written by David Raingeard and Romain Tisserand.

All code was written from scratch except for:

 - Z80 Emulation using MZ80 core (courtesy of Neil Bradley).
 - SN76496 Emulation using MAME routines (courtesy of MAME Team).

The emulator will be open source as soon as we are happy with it 

----------------
- Koyote 0.5.0 -
----------------

* Added: Classic/Color hardware autodetection 
* Added: Drag and drop support 
* Optimized: Half brightness scanlines and skin filters 
* Changed: Rom loading system 
* Changed: Configuration file 

----------------
- Koyote 0.4.0 -
----------------

* Real snk bios full support !
* Added K1GE compatibility mode
* Added K1GE mode
* Added hard reset
* Fixed direct flash memory accesses emulation bug

----------------
- Koyote 0.3.0 -
----------------

* Added real bios support (work in progress)
* Added support for direct flash accesses (multipack roms work now, thanks to flavor)
* Added support for different sizes and manufacturers of flash memories
* Fixed fm synthesis
* Fixed dac
* Fixed directsound code
* Fixed Ex R,R'opcode
* Fixed fullscreen/windowed switch
* Improved dma
* Improved timers

----------------
- Koyote 0.2.0 -
----------------

 * Added: 32bpp support
 * Added: Zip file support
 * Added: Skins support
 * Added: multilanguage features
 * Added: 10 default slots for saved states
 * Added: Preliminary support for TCP/IP Link Cable Emulation
 * Added: Last played Roms (history)
 * Fixed: Save/Load states
 * Fixed: Interface bugs
 * Fixed: Several serious bugs in TLCS900-H cpu core
 * Fixed: SWI 1 calls
 * Fixed: Flash emulation
 * Fixed: Hardware stretch mode bug
 * Fixed: Koyote configuration file path bug
 * Fixed: Controller plugin configuration file path bug
 * Improved: TLCS900-H timing
 * Improved: sound timing
 * Improved: BIOS emulation
 * Rewroten: sound emulation
   - Replaced SEAL Audio Library by DirectSound code
   - Special note : DAC is disabled in this release 

FAQ:
----

Q: How can I change of skin ?
A: Download a skin from koyote's web site, and unzip it in the skins directory.
   Then open koyote.cfg and modify the 'Skin' and 'SkinNFO' parameters

Q: How can I change of language ?
A: Download a language file from koyote's web site and unzip it in the locale directory
   Then open koyote.cfg and modify the 'Language' parameter

Q: How does netplay works ?
A: First you have to know that netplay is in early stages of developement, and may not work
   very well. You have to launch the 'kserver' file to install the netplay server.
   Then get the server's ip by typing something like 'ipconfig' in a terminal.
   Launch koyote on two computers and choose the  the Setup->netplay option and configure
   netplay. Then load a game.

----------------
- Koyote 0.1.0 -
----------------

Status :
--------

TLCS900H Emulation      : Complete (some opcodes are still wrong)
Z80 Emulation           : Complete
FM Synthesis            : Complete (a bit crappy though)
DAC                     : Complete
Color Graphic Emulation : Complete
Mono Graphic emulation  : Partial
Link Emulation          : To Do (using TCP/IP)


Compatibility :
---------------

All PD roms work perfectly.
Most commercial games should be fully playable with little to no graphic glitches.
Some of them are not playable due to badly emulated opcodes
Sound is a bit crappy.

Koyote was successfully tested on the following configurations:

 - Intel Pentium III 700 Mhz with 256 Mb of RAM under Windows 2000
 - Intel Pentium III 500 Mhz with 224 Mb of RAM under Windows 2000 SP2
 - Intel Celeron 800 Mhz with 128 Mb of RAM under Windows 2000
 - Intel Celeron 800 Mhz with 128 Mb of RAM under Windows 98 SE
 - Intel Celeron 466 Mhz with 64 Mb of RAM under Windows 98

If it doesn't work with your configuration, don't hesitate to contact us. 



Special note : 
--------------

Due to recent NeoPop source code release, we want to make things clear : we did not use neopop source code, but it helped us to understand some things we were missing. 

Greetings to NeoPop author by the way and thanks a lot for releasing your source code !

Contact :
---------

E-Mail : 	david.raingeard@etu.univ-tours.fr 
		romaintisserand@wanadoo.fr

Offical Web Site : http://koyote.emu-france.com


